package may_13;

public class Ex03 {

	public static void main(String[] args) {
		int x = 20;
		int y = 50;
		int max;
		
		//조건식? True_value:False_value
		max = (x>y)? x: y;
		
	
		System.out.printf("최댓값:%d\n", max);

	}

}
