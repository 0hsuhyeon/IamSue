package may_13;

// 지금까지 학습한 기법들을 이용하요 1~5까지의 정수에 대하여 제곱값과 세제곱 값을 화면에 출력하는 프로그램을 작성하시오
// (정수값의 증가는 증감 연산자를 활용한다)
public class Ex05 {

		public static void main(String[] args) {
			System.out.println("Int		Square		Cube");
		
			
		}
}
