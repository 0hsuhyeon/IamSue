package kr.ac.kepo.member;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//브라우저 주소창에
//http://localhost:8000/exwe/member/addform.do
//를 입력하고 엔터키를 입력하면 
//브라우저 화면에 회원 정보를 입력할 수 있는 엘리먼트들이 출력되도록 

@WebServlet("/member/addform.do")
public class MamberAddFromServlet extends HttpServlet {
	Scanner s = new Scanner(System.in);
	{
		// 초기화 블럭
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	String url ="jdbc:oracle:thin:@localhost:1521:xe";
	String user ="com"; 
	String password ="com01"; 
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");//응답내용이 text/html임을 알리도록 설정
		resp.setCharacterEncoding("UTF-8"); //응답내용의 문자 인코딩 설정
		PrintWriter out = resp.getWriter(); //응답객체에 출력할 수 있는 스트림 가져오기
	

		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.print("<head>                           ");
		out.print("<meta charset='UTF-8'>           ");
		out.print("<title>회원관리</title> ");
		out.print("</head>                          ");
		out.print("<body align=\"center\">                           ");
		out.print("	<h1>회원 추가</h1>       ");
		
		//ContextPath: 현재 웹 애플리케이션(프로젝트)의 고유 경로
		out.print("	<form action='"+req.getContextPath()+"/member/add.do' method='post'>      ");
		out.print("	<fieldset>      ");
		
		out.print("	<label for=\"memId\">신규 아이디 </label>     ");
		out.print("	<input type=\"text\" name=\"memId\"><br/>      ");
		
		out.print("	<label for=\"memPass\">비밀번호 </label>     ");
		out.print("	<input type=\"text\" name=\"memPass\"> <br/>      ");
		
		out.print("	<label for=\"mamName\">이름 </label>     ");
		out.print("	<input type=\"text\" name=\"memName\"> <br/>      ");
		
		out.print("	<label for=\"mamPoint\">포인트 </label>     ");
		out.print("	<input type=\"text\" name=\"memPoint\"> <br/>      ");
		
		out.print(" <input type=\"submit\" value=\"저장\">");


		out.print("	</fieldset>      ");
		out.print("	</form>      ");
		out.print("</body>                          ");
		out.print("</html>                          ");
		
	}

}
